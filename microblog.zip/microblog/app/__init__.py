# this creates the web application
from flask import Flask
from config import Config

app = Flask(__name__)
# tells Flask to read and apply it using method 
app.config.from_object(Config)

# the routes module needs to import the app variable I defined above
#   before it can work. Therefore, it's below the instantiation, b/c
#   python reads files top to bottom, thus avoiding the error that
#   results from mutual references b/w the two files.
from app import routes
